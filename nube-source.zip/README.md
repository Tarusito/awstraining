# Nube — AWS study app

Prepared deployment snapshot with all 9,822 questions translated to Spanish,
Cloud Practitioner / Solutions Architect Associate discussions, and the AWS service catalog.

Render Web Service settings:

- Runtime: Python (version selected by `.python-version`).
- Compute plan: Free.
- Build: `pip install -r requirements-render.txt && python scripts/prepare_render.py`
- Start: `python scripts/start_study.py`
- Environment: `HOST=0.0.0.0` (`PORT` is supplied by Render).
- HTTP health check: `/healthz`.

The build downloads a checksum-verified offline translation model. No API key is required.
Question and service data are part of this snapshot; do not rebuild them from the upstream repo.
Progress is stored in each browser. Translation sentence caching is ephemeral on Render Free;
cached translations can be generated again after restarts. Original texts remain available.
Free services sleep after inactivity; the first request can require a cold start.
