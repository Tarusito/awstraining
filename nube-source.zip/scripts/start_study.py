#!/usr/bin/env python3
"""Serve the AWS study app on this computer."""

from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
import json
import os
import subprocess
import sys
from threading import Semaphore
from urllib.parse import urlsplit

from build_study import DATA, ROOT, main as build

TRANSLATION_SLOT = Semaphore(1)


class StudyHandler(SimpleHTTPRequestHandler):
    def do_GET(self):
        if self.path == "/healthz":
            return self.send_json(200, {"status": "ok"})
        return super().do_GET()

    def list_directory(self, path):
        self.send_error(404)
        return None

    def send_json(self, status, data):
        body = json.dumps(data, ensure_ascii=False).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_POST(self):
        if self.path != "/api/translate":
            return self.send_json(404, {"error": "Ruta no disponible."})
        origin = self.headers.get("Origin")
        if origin and (urlsplit(origin).scheme not in {"http", "https"} or urlsplit(origin).netloc != self.headers.get("Host")):
            return self.send_json(403, {"error": "Origen no permitido."})
        if self.headers.get("Content-Type", "").split(";")[0] != "application/json":
            return self.send_json(415, {"error": "Se requiere JSON."})
        try:
            length = int(self.headers.get("Content-Length", "0"))
            if not 0 < length <= 4096:
                raise ValueError()
            payload = json.loads(self.rfile.read(length))
            manifest = json.loads((DATA / "manifest.json").read_text())
            if not isinstance(payload, dict) or payload.get("exam") not in {e["id"] for e in manifest["exams"]}:
                raise ValueError()
            questions = json.loads((DATA / f"{payload['exam']}.json").read_text())["questions"]
            q = next((q for q in questions if q["id"] == payload.get("question")), None)
            if q is None:
                raise ValueError()
            if "comment" in payload:
                if not q.get("discussionCount"):
                    raise ValueError()
                comments = json.loads((DATA / "discussions" / payload["exam"] / f"{q['id']}.json").read_text())["comments"]
                if not any(comment["id"] == payload["comment"] for comment in comments):
                    raise ValueError()
        except (ValueError, TypeError):
            return self.send_json(400, {"error": "Pregunta no válida."})
        if "comment" not in payload and q.get("es"):
            return self.send_json(200, q["es"])
        python = ROOT / ".cache/translation/venv/bin/python"
        if not python.exists():
            python = sys.executable
        if not TRANSLATION_SLOT.acquire(blocking=False):
            return self.send_json(429, {"error": "El traductor está ocupado. Inténtalo de nuevo en unos segundos."})
        try:
            result = subprocess.run(
                [str(python), str(ROOT / "scripts/translate_question.py")],
                input=json.dumps(payload), text=True, capture_output=True, timeout=120, check=True,
            )
            return self.send_json(200, json.loads(result.stdout))
        except (subprocess.SubprocessError, json.JSONDecodeError):
            return self.send_json(503, {"error": "No se pudo traducir esta pregunta. Puedes seguir con el original en inglés e intentarlo de nuevo."})
        finally:
            TRANSLATION_SLOT.release()


if __name__ == "__main__":
    if not (DATA / "manifest.json").exists():
        if not (ROOT / "downloads/aws/summary.json").exists():
            raise SystemExit("First run: python3 scripts/download_all_aws.py")
        build()
    handler = partial(StudyHandler, directory=str(ROOT / "study"))
    host = os.environ.get("HOST", "0.0.0.0" if os.environ.get("RENDER") else "127.0.0.1")
    port = int(os.environ.get("PORT", "8765"))
    try:
        server = ThreadingHTTPServer((host, port), handler)
    except OSError as error:
        raise SystemExit(f"Cannot start the server: {error}. Check whether port {port} is already in use.")
    print(f"Nube: http://{host}:{port} · Ctrl+C to stop", flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
