#!/usr/bin/env python3
"""Isolated worker for one question requested by the local study server."""

import json
import re
import sys

from build_study import DATA
from local_translation import LocalTranslator


if __name__ == "__main__":
    request = json.load(sys.stdin)
    manifest = json.loads((DATA / "manifest.json").read_text())
    exam = request.get("exam")
    identity = request.get("question", "")
    if exam not in {e["id"] for e in manifest["exams"]} or not re.fullmatch(r"[a-f0-9]{20}", identity):
        raise SystemExit("Invalid question")
    questions = json.loads((DATA / f"{exam}.json").read_text())["questions"]
    question = next(q for q in questions if q["id"] == identity)
    if "comment" in request:
        if not question.get("discussionCount"):
            raise SystemExit("Discussion not available for this exam")
        comments = json.loads((DATA / "discussions" / exam / f"{identity}.json").read_text())["comments"]
        comment = next(c for c in comments if c["id"] == request["comment"])
        engine = LocalTranslator()
        try:
            result = {"text": engine.translate([comment["text"]])[comment["text"]]}
        finally:
            engine.close()
    elif question.get("es"):
        result = question["es"]
    else:
        engine = LocalTranslator()
        try:
            result = engine.question(question)
        finally:
            engine.close()
    print(json.dumps(result, ensure_ascii=False))
