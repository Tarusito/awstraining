#!/usr/bin/env python3
"""Validate the packaged study bank and prepare the offline model during a Render build."""

import hashlib
import json
from pathlib import Path
import urllib.request
import zipfile

from build_study import DATA, ROOT

MODEL_URL = "https://argos-net.com/v1/translate-en_es-1_0.argosmodel"
MODEL_SHA256 = "d698d0ef87ad70d5d184b7fa6965905bf4368f09a2bb9ffb165a79bac96af0c4"


def validate_bank():
    manifest = json.loads((DATA / "manifest.json").read_text())
    total = 0
    for exam in manifest["exams"]:
        questions = json.loads((DATA / f"{exam['id']}.json").read_text())["questions"]
        if len(questions) != exam["count"] or any(not q.get("es") for q in questions):
            raise ValueError(f"Missing questions or Spanish translations for {exam['id']}")
        for question in questions:
            if question.get("discussionCount"):
                path = DATA / "discussions" / exam["id"] / f"{question['id']}.json"
                if len(json.loads(path.read_text())["comments"]) != question["discussionCount"]:
                    raise ValueError(f"Missing comments for {question['id']}")
        total += len(questions)
    if total != manifest["total"]:
        raise ValueError("The packaged question bank is incomplete")
    services = json.loads((ROOT / "study/content/aws-services.json").read_text())
    groups = json.loads((ROOT / "study/content/aws-certifications.json").read_text())
    known = {entry["id"] for entry in services["entries"]}
    if any(service["id"] not in known for group in groups["groups"] for service in group["services"]):
        raise ValueError("A certification references a missing service")
    print(f"Packaged: {total} questions, {len(services['entries'])} service cards, {len(groups['groups'])} certification groups.", flush=True)


def prepare_model():
    cache = ROOT / ".cache/translation"
    cache.mkdir(parents=True, exist_ok=True)
    archive = cache / "en-es.argosmodel"
    if not archive.exists():
        temporary = archive.with_suffix(".tmp")
        print("Downloading the offline English-Spanish model…", flush=True)
        with urllib.request.urlopen(MODEL_URL, timeout=120) as response, temporary.open("wb") as target:
            while chunk := response.read(1024 * 1024):
                target.write(chunk)
        temporary.replace(archive)
    with archive.open("rb") as source:
        if hashlib.file_digest(source, "sha256").hexdigest() != MODEL_SHA256:
            raise ValueError("The translation model checksum does not match")
    with zipfile.ZipFile(archive) as model:
        for member in model.infolist():
            destination = (cache / member.filename).resolve()
            if not destination.is_relative_to(cache.resolve()):
                raise ValueError("Invalid model archive path")
        model.extractall(cache)
    if not (cache / "en_es/model/model.bin").is_file():
        raise ValueError("The offline model is incomplete")
    print("Offline translation model ready.", flush=True)


if __name__ == "__main__":
    validate_bank()
    prepare_model()
