"""Shared offline translation engine and persistent sentence cache."""

import re
import sqlite3

import ctranslate2
import sentencepiece

from build_study import ROOT


def polish(text):
    text = re.sub(r"\b(?:cubos|baldes)\b", "buckets", text, flags=re.I)
    text = re.sub(r"\b(?:cubo|balde)\b", "bucket", text, flags=re.I)
    text = re.sub(r"\bganglios\b", "nodos", text, flags=re.I)
    text = re.sub(r"\bganglio\b", "nodo", text, flags=re.I)
    text = re.sub(r"\boleoductos\b", "pipelines", text, flags=re.I)
    return re.sub(r"\boleoducto\b", "pipeline", text, flags=re.I)


class LocalTranslator:
    def __init__(self):
        model = ROOT / ".cache/translation/en_es"
        self.tokenizer = sentencepiece.SentencePieceProcessor(model_file=str(model / "sentencepiece.model"))
        self.translator = ctranslate2.Translator(str(model / "model"), device="cpu", compute_type="int8", inter_threads=4, intra_threads=1)
        self.memory = sqlite3.connect(ROOT / ".cache/translation/memory.sqlite3", timeout=60)
        self.memory.execute("CREATE TABLE IF NOT EXISTS translations (source TEXT PRIMARY KEY, translated TEXT NOT NULL)")
        self.known = {source: polish(translated) for source, translated in self.memory.execute("SELECT source, translated FROM translations")}

    def translate(self, fields):
        pieces = {}
        for text in fields:
            sentences = re.split(r"(?<=[.!?])\s+(?=[A-Z0-9¿])|\n+", text)
            chunks = []
            for sentence in sentences:
                tokens = self.tokenizer.encode(sentence, out_type=str)
                chunks.extend(self.tokenizer.decode(tokens[i:i + 180]) for i in range(0, len(tokens), 180))
            pieces[text] = chunks
        missing = list(dict.fromkeys(part for chunks in pieces.values() for part in chunks if part not in self.known))
        for offset in range(0, len(missing), 128):
            batch = missing[offset:offset + 128]
            results = self.translator.translate_batch(
                [self.tokenizer.encode(text, out_type=str) for text in batch],
                beam_size=1, max_batch_size=512, batch_type="tokens",
                max_decoding_length=512, repetition_penalty=1.05,
            )
            for source, result in zip(batch, results):
                translated = polish(self.tokenizer.decode(result.hypotheses[0]).strip())
                if not translated:
                    raise ValueError("Empty translation")
                self.known[source] = translated
                self.memory.execute("INSERT OR REPLACE INTO translations VALUES (?, ?)", (source, translated))
            self.memory.commit()
        return {text: "\n".join(self.known[p] for p in chunks) for text, chunks in pieces.items()}

    def question(self, q):
        translated = self.translate([q["stem"], *(c["text"] for c in q["choices"])])
        return {"stem": translated[q["stem"]], "choices": [translated[c["text"]].replace("\n", " ") for c in q["choices"]]}

    def close(self):
        self.memory.close()
