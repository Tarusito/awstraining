#!/usr/bin/env python3
"""Prepare the downloaded AWS questions for the static study app."""

import hashlib
import html
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "study" / "data"
DISCUSSION_EXAMS = {
    "aws-certified-cloud-practitioner-clf-c02": "AWS-Certified-Cloud-Practitioner-CLF-C02",
    "aws-certified-solutions-architect-associate-saa-c03": "AWS-Certified-Solutions-Architect---Associate-SAA-C03",
}


def save_json(path, value):
    temporary = path.with_suffix(".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, separators=(",", ":")))
    temporary.replace(path)


def clean(text):
    return html.unescape(re.sub(r"<[^>]+>", "", re.sub(r"<br\s*/?>", "\n", text or "", flags=re.I))).strip()


def load_discussions(prefix):
    by_source = {}
    for path in sorted((ROOT / ".cache/examtopics-data/Amazon").glob(f"{prefix}_*.json")):
        questions = json.loads(path.read_text())["pageProps"]["questions"]
        for question in questions:
            comments = []

            def walk(entries, parent=None):
                for entry in entries:
                    text = clean(entry.get("content", ""))
                    author = entry.get("poster") or "Anónimo"
                    if text:
                        identity = hashlib.sha256(json.dumps([entry.get("comment_id"), author, text, len(comments)], ensure_ascii=False).encode()).hexdigest()[:20]
                        votes = re.search(r"-?\d+", str(entry.get("upvote_count", "0")))
                        comments.append({"id": identity, "author": author, "text": text, "votes": int(votes[0]) if votes else 0, "replyTo": parent})
                    walk(entry.get("comments") or [], author)

            walk(question.get("discussion") or [])
            by_source[question["url"]] = comments
    if not by_source:
        raise ValueError(f"Discussion source cache not found for {prefix}. Run scripts/download_all_aws.py first.")
    return by_source


def main():
    summary = json.loads((ROOT / "downloads/aws/summary.json").read_text())
    DATA.mkdir(parents=True, exist_ok=True)
    exams = []
    for exam in summary["exams"]:
        slug = Path(exam["json"]).stem
        discussions = load_discussions(DISCUSSION_EXAMS[slug]) if slug in DISCUSSION_EXAMS else None
        if discussions is not None:
            (DATA / "discussions" / slug).mkdir(parents=True, exist_ok=True)
        path = DATA / f"{slug}.json"
        previous = {}
        if path.exists():
            previous = {(q["source"], q["stem"], tuple((c["key"], c["text"]) for c in q["choices"])): q.get("es") for q in json.loads(path.read_text())["questions"]}
        questions = []
        for number, q in enumerate(json.loads((ROOT / "downloads/aws" / exam["json"]).read_text()), 1):
            choices = []
            for block in q["questions"]:
                for match in re.finditer(r"\*\*([A-Z]):\*\*\s*(.*?)(?=\n\s*\*\*[A-Z]:\*\*|\Z)", block, re.S):
                    choices.append({"key": match[1], "text": clean(match[2])})
            stem = clean(q["header"])
            identity = hashlib.sha256(json.dumps([q["question_link"], stem, choices], ensure_ascii=False).encode()).hexdigest()[:20]
            existing_translation = previous.get((q["question_link"], stem, tuple((c["key"], c["text"]) for c in choices)))
            keys = {c["key"] for c in choices}
            answer = re.sub(r"[\s,;]+", "", q["answer"])
            answers = list(answer) if answer and all(letter in keys for letter in answer) else []
            questions.append({
                "id": identity, "number": number, "stem": stem, "choices": choices,
                "answers": answers, "source": q["question_link"], "es": existing_translation,
                "images": re.findall(r"https?://\S+", q["content"]),
            })
            if discussions is not None:
                comments = discussions.get(q["question_link"], [])
                questions[-1]["discussionCount"] = len(comments)
                save_json(DATA / "discussions" / slug / f"{identity}.json", {"comments": comments})
        save_json(path, {"questions": questions})
        code = re.search(r"\b([A-Z]{3}-C\d\d)\b", exam["exam"])
        name = re.sub(r"-+", " ", exam["exam"]).removeprefix("AWS Certified ").removeprefix("AWS ")
        if code:
            name = name.removesuffix(code[1].replace("-", " ")).strip()
        priority = 0 if "CLF-C02" in exam["exam"] else 1 if "SAA-C03" in exam["exam"] else 2 if "SAP-C02" in exam["exam"] else 3
        exams.append({
            "id": slug, "name": name, "code": code[1] if code else "Versión anterior",
            "count": len(questions), "translated": sum(bool(q["es"]) for q in questions),
            "priority": priority, "legacy": not bool(code),
        })
    exams.sort(key=lambda e: (e["priority"], e["name"]))
    save_json(DATA / "manifest.json", {"exams": exams, "total": summary["total_questions"], "sourceCommit": summary["commit"]})
    print(f"Prepared {len(exams)} exams, {summary['total_questions']} questions.")


if __name__ == "__main__":
    main()
