# Nube — Estudio de certificaciones AWS

Página local para consultar las 9.822 preguntas descargadas, agrupadas en 23 exámenes o versiones. Da acceso directo a Cloud Practitioner CLF-C02, Solutions Architect Associate SAA-C03 y Solutions Architect Professional SAP-C02.

Desde la raíz del repo:

```bash
python3 scripts/start_study.py
```

Abre [Nube](http://127.0.0.1:8765). El servidor escucha únicamente en este equipo. No necesita una cuenta ni una clave API.

## Uso

- **Todas las certificaciones** abre la biblioteca completa, con búsqueda por nombre o código.
- **English / Español / EN + ES** cambia el enunciado y las opciones. Conserva la selección actual al cambiar de idioma.
- Selecciona una o varias opciones y pulsa **Comprobar respuesta**. Se compara con la respuesta de la fuente.
- **Ver respuesta** permite consultar la solución sin contar la pregunta como practicada.
- En Cloud Practitioner **CLF-C02** y Solutions Architect Associate **SAA-C03**, después de comprobar o ver la respuesta aparece **Explicación y debate**. Despliega los comentarios originales de ExamTopics con autor, votos y respuestas entre usuarios. Se cargan al abrirlos y puedes mostrar más de cinco.
- Cada comentario tiene **Traducir al español** cuando estás en Español o EN + ES. La traducción se ejecuta y guarda en este equipo; **Ver original** y la vista bilingüe permiten contrastarla. Los comentarios son opiniones de la comunidad y pueden discrepar o contener errores; no son una explicación oficial ni un resumen generado.
- La estrella guarda preguntas en **Marcadas**. **Para repasar** reúne las que has fallado.
- Busca por texto en ambos idiomas. Usa el mapa, el número de pregunta, los botones o las flechas del teclado para navegar.

El progreso, los marcadores, el idioma y la última pregunta de cada certificación se guardan en `localStorage` del navegador. No se sincronizan entre navegadores o equipos. Usa siempre la misma dirección y puerto para conservar ese espacio de estudio.

## Catálogo de servicios AWS

**Servicios AWS**, en la navegación de Nube, abre [el catálogo local](http://127.0.0.1:8765/services.html). Contiene 333 fichas en español en 24 categorías, con una definición, tres características principales y enlaces a fuentes oficiales. El filtro **Esenciales para estudiar** destaca 90 entradas útiles para repasar Cloud Practitioner y Solutions Architect; no representa una lista oficial del temario.

Puedes buscar por nombre, siglas o conceptos en español e inglés, filtrar por categoría, ordenar alfabéticamente y guardar fichas con la estrella. Los guardados del catálogo se almacenan en `nube.services.saved.v1`, separados del progreso de preguntas. Los filtros de búsqueda y categoría se conservan en la URL.

**Por certificación** muestra primero **Cloud Practitioner CLF-C02** (109 fichas) y **Solutions Architect Associate SAA-C03** (116 fichas). El selector incluye las otras 11 guías oficiales consultadas y 15 versiones adicionales del banco local. La selección se conserva en el parámetro `cert` de la URL y se combina con búsqueda, categorías y guardados. Los recuentos de categoría se ajustan al grupo seleccionado.

Las 13 agrupaciones oficiales proceden de las listas **In-Scope AWS Services** enlazadas desde el [índice de guías de AWS](https://docs.aws.amazon.com/aws-certification/latest/examguides/aws-certification-exam-guides.html), revisadas el 25 de octubre de 2026. Cada grupo enlaza a su lista y cada ficha muestra el nombre o las funciones citadas en ella. Una función puede remitir a la ficha de su servicio padre; varias referencias se reúnen en una sola ficha. Las referencias sin ficha se muestran en un desplegable del grupo. Las listas oficiales no son exhaustivas y los códigos de las guías pueden diferir de los del banco de preguntas.

Las agrupaciones de **Versiones del banco local** reúnen servicios cuyos nombres o siglas se detectaron en los enunciados y opciones de esa versión. Se identifican expresamente como menciones del banco, no como una lista oficial de alcance del examen. Incluyen las versiones anteriores sin código y los bancos MLA-C01, SCS-C02 y PAS-C01. Las agrupaciones se distribuyen en `study/content/aws-certifications.json`; el catálogo funciona sin conexión externa para consultarlas.

La revisión del 25 de octubre de 2026 combina el [directorio de productos](https://aws.amazon.com/products/) y el [índice de documentación de AWS](https://docs.aws.amazon.com/), agrupando nombres equivalentes. Incluye servicios, funciones, herramientas e infraestructura, identificados en las fichas; no enumera cada API o cada función individual de AWS. Se señalan los estados de mantenimiento, retirada anunciada y retirada cuando existe una coincidencia del producto con las [tablas oficiales de ciclo de vida](https://docs.aws.amazon.com/general/latest/gr/service-lifecycle.html). Los avisos de una función concreta no se aplican a todo su servicio padre.

El contenido está incluido en `study/content/aws-services.json`, fuera de los datos generados de preguntas. Funciona localmente sin traducción ni consultas externas durante la navegación; los enlaces de documentación abren AWS al pulsarlos. La fecha es una revisión del catálogo, no una sincronización automática. Para actualizar una ficha, edita su contenido en ese JSON y contrasta su enlace oficial.

## Traducción

Cloud Practitioner CLF-C02, Solutions Architect Associate SAA-C03 y Solutions Architect Professional SAP-C02 tienen todas sus preguntas traducidas por adelantado. Para el resto, al elegir Español o EN + ES, la página traduce localmente las preguntas que lo necesiten y guarda el resultado en una memoria de traducción. La primera consulta puede tardar unos segundos; mientras tanto se muestra el original.

Se usa el [modelo inglés-español de Argos Translate](https://github.com/argosopentech/argospm-index), ejecutado con CTranslate2 y SentencePiece. El navegador habla únicamente con el servidor de este ordenador para traducir; los enunciados no se envían a un servicio externo. Las fuentes tipográficas también están incluidas localmente.

**No son las traducciones oficiales del examen AWS.** El modelo es generalista y puede cometer errores con términos técnicos. La vista bilingüe permite contrastar siempre el original. Las letras de las opciones y sus respuestas se conservan, sin reordenarlas. No se inventan opciones o respuestas cuando faltan en la fuente.

Para preparar el traductor después de instalar desde cero o actualizar los datos:

```bash
python3 scripts/download_all_aws.py
sh scripts/setup_translation.sh --model-only
```

La primera preparación descarga un modelo de unos 84 MB e instala CTranslate2 y SentencePiece en un entorno aislado dentro de `.cache/translation/`. Necesita conexión a Internet para esas descargas. Después la inferencia se ejecuta localmente. Recarga la página para ver los nuevos datos.

Si quieres traducir de antemano absolutamente todo el banco, puedes ejecutar `sh scripts/setup_translation.sh` sin `--model-only`. Esa preparación completa puede tardar bastante. Guarda los avances y se puede interrumpir y reanudar sin repetir lo ya terminado. La traducción al consultar funciona sin esperar a esa preparación completa.

Para reconstruir los datos sin ejecutar traducciones:

```bash
python3 scripts/build_study.py
```

Las traducciones existentes se conservan cuando el original no cambia. `study/data/`, `downloads/` y `.cache/` son datos generados y están ignorados por Git.

## Verificación

```bash
node --check study/app.mjs
node --check study/services.mjs
python3 scripts/validate_study.py
```

La validación comprueba la cobertura completa, identificadores únicos, enunciados y opciones iguales a sus fuentes, respuestas válidas, traducción completa de los tres exámenes prioritarios y correspondencia entre las opciones de todas las traducciones ya guardadas. No sustituye una revisión lingüística humana de todas las traducciones.

## Despliegue en Render Free

La aplicación usa un único **Web Service** Python para servir las páginas y traducir comentarios bajo demanda. No requiere base de datos externa ni clave API. La configuración prevista es:

- Plan de cómputo: **Free**.
- Build: `pip install -r requirements-render.txt && python scripts/prepare_render.py`.
- Start: `python scripts/start_study.py`.
- Variable `HOST=0.0.0.0`; Render proporciona `PORT`.
- Health check HTTP: `/healthz`.

`prepare_render.py` comprueba el banco empaquetado y descarga el modelo inglés-español verificando su SHA-256. Solo se admite una traducción simultánea; si está ocupado, el servidor responde 429 y el original permanece disponible.

El banco `study/data/` está ignorado por Git en este repo. Para exportar una copia completa que sí pueda desplegarse, ejecuta:

```bash
python3 scripts/package_render.py
```

El comando valida las 9.822 preguntas traducidas, los debates y las agrupaciones, y crea una carpeta nueva dentro de `.cache/render/`. Esa carpeta contiene los recursos de Nube, los datos preparados y los scripts mínimos del servidor, con un `.gitignore` propio que permite versionar el banco. Debe subirse a un repositorio tuyo accesible desde Render. No sirve desplegar directamente el repositorio original de GitHub, porque no contiene esta versión local de la web.

El plan Free suspende el servicio tras un período sin tráfico; la siguiente visita puede tardar en arrancar. La caché de traducciones se almacena en disco efímero y se puede reconstruir después de reinicios. El progreso y los favoritos permanecen en el navegador, separados por dirección: el progreso de `127.0.0.1` no se transfiere automáticamente a la nueva dirección pública.
